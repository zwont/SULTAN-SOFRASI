from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
from datetime import datetime
from zoneinfo import ZoneInfo
import json, threading, uuid, os

ROOT = Path(__file__).resolve().parent
LOCK = threading.Lock()

DEFAULT_MENU = [
    {'key':'yemek','title':'Yemekler','icon':'🍽️','items':['Etli Kuru Fasulye','Bulgur Pilavı','Pirinç Pilavı','Köfte & Patates']},
    {'key':'salata','title':'Salatalar','icon':'🥗','items':['Havuç Tarator','Mor Lahana','Mevsim Salata','Çoban Salata']},
    {'key':'tatli','title':'Tatlılar','icon':'🍰','items':['Sütlaç','Baklava']},
    {'key':'icecek','title':'İçecekler','icon':'🥤','items':['Ayran','Kola Zero']},
]

MENU_FILE = ROOT / 'menu.json'
ORDERS_FILE = ROOT / 'orders.json'
PHOTOS_FILE = ROOT / 'photos.json'

def read_json(path, default):
    with LOCK:
        try:
            if path.exists():
                return json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            pass
        return default

def write_json(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    with LOCK:
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(path)

def clean_menu(menu):
    if not isinstance(menu, list) or not menu:
        return None
    out=[]
    for i,c in enumerate(menu[:50]):
        if not isinstance(c,dict):
            continue
        items=c.get('items',[])
        if not isinstance(items,list): items=[]
        out.append({
            'key': str(c.get('key') or f'cat_{i}')[:80],
            'title': str(c.get('title','Kategori'))[:100],
            'icon': str(c.get('icon','🍽️'))[:20],
            'items': [str(x)[:100] for x in items[:100]]
        })
    return out or None

def init_files():
    if not MENU_FILE.exists(): write_json(MENU_FILE, DEFAULT_MENU)
    if not ORDERS_FILE.exists(): write_json(ORDERS_FILE, [])
    if not PHOTOS_FILE.exists(): write_json(PHOTOS_FILE, {'photoA':'','photoB':''})

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_json(self,obj,code=200):
        raw=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate')
        self.send_header('Content-Length',str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def read_body(self):
        n=int(self.headers.get('Content-Length','0'))
        return json.loads(self.rfile.read(n) or b'{}')

    def do_GET(self):
        path=urlparse(self.path).path
        if path=='/api/menu': return self.send_json(read_json(MENU_FILE, DEFAULT_MENU))
        if path=='/api/orders': return self.send_json(read_json(ORDERS_FILE, []))
        if path=='/api/photos': return self.send_json(read_json(PHOTOS_FILE, {'photoA':'','photoB':''}))
        if path=='/': self.path='/index.html'
        return super().do_GET()

    def do_PUT(self):
        path=urlparse(self.path).path
        try: data=self.read_body()
        except Exception as e: return self.send_json({'error':str(e)},400)

        if path=='/api/menu':
            menu=clean_menu(data.get('menu'))
            if menu is None: return self.send_json({'error':'menu required'},400)
            write_json(MENU_FILE, menu)
            return self.send_json(menu)

        if path=='/api/photos':
            current=read_json(PHOTOS_FILE, {'photoA':'','photoB':''})
            for key in ('photoA','photoB'):
                if key in data:
                    val=data[key] or ''
                    if not isinstance(val,str) or len(val)>8_000_000:
                        return self.send_json({'error':'invalid photo'},400)
                    current[key]=val
            write_json(PHOTOS_FILE,current)
            return self.send_json({'ok':True})

        return self.send_json({'error':'not found'},404)

    def do_POST(self):
        path=urlparse(self.path).path
        if path!='/api/orders': return self.send_json({'error':'not found'},404)
        try:
            data=self.read_body()
            name=str(data.get('name','')).strip()
            items=data.get('items',[])
            if not name or not isinstance(items,list) or not items:
                return self.send_json({'error':'name/items required'},400)
            clean=[]
            for x in items[:50]:
                if isinstance(x,dict):
                    try: qty=max(1,int(x.get('qty',1)))
                    except Exception: qty=1
                    clean.append({'name':str(x.get('name','Ürün'))[:100],'qty':qty})
                else:
                    clean.append({'name':str(x)[:100],'qty':1})
            order={
                'id':uuid.uuid4().hex[:10],
                'name':name[:80],
                'message':str(data.get('message',''))[:500],
                'items':clean,
                'time':datetime.now(ZoneInfo('Europe/Istanbul')).strftime('%d.%m.%Y %H:%M:%S')
            }
            orders=read_json(ORDERS_FILE, [])
            if not isinstance(orders,list): orders=[]
            orders.insert(0,order)
            write_json(ORDERS_FILE,orders)
            return self.send_json(order,201)
        except Exception as e:
            return self.send_json({'error':str(e)},400)

    def do_DELETE(self):
        path=urlparse(self.path).path
        if not path.startswith('/api/orders/'):
            return self.send_json({'error':'not found'},404)
        oid=path.rsplit('/',1)[-1]
        orders=read_json(ORDERS_FILE,[])
        new=[o for o in orders if str(o.get('id'))!=oid]
        if len(new)==len(orders): return self.send_json({'error':'order not found'},404)
        write_json(ORDERS_FILE,new)
        return self.send_json({'ok':True})

if __name__=='__main__':
    init_files()
    port=int(os.environ.get('PORT','8000'))
    print(f'Sultan Sofrası çalışıyor: 0.0.0.0:{port} | file-backed menu/orders')
    ThreadingHTTPServer(('0.0.0.0',port),Handler).serve_forever()
